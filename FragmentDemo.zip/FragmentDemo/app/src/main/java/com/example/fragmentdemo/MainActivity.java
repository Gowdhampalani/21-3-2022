package com.example.fragmentdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements Leftfragment.OnGolistener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Replace leftcontainer with left Fragment
        getSupportFragmentManager()
                .beginTransaction().
                replace(R.id.leftfrgcontainer,new Leftfragment()).commit();



    }

    @Override
    public void onGo(String name) {
        getSupportFragmentManager()
                .beginTransaction().
                replace(R.id.rightfrgcontainer,RightFragment.newInstance(name)).commit();

    }
}