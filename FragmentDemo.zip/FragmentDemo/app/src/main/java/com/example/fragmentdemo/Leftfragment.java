package com.example.fragmentdemo;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class Leftfragment extends Fragment {

    EditText nameEt;
    Button gobtn;
    OnGolistener onGolistener;


    // attaching interface to fragment
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        onGolistener = (OnGolistener) context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.leftfrg,container,false);



    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        nameEt = (EditText)view.findViewById(R.id.lefr_nameEt);
        gobtn = (Button)view.findViewById(R.id.left_gobtn);

        gobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = nameEt.getText().toString();

                // Initiate listener
                if (onGolistener!=null)
                {
                    onGolistener.onGo(name);
                }
            }
        });

    }
    // an interface - implemented by Activity
    interface OnGolistener
    {
        public void onGo(String name);
    }

}
